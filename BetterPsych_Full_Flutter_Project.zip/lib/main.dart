import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';
import 'package:url_launcher/url_launcher.dart';

// ======= MODELS =======
class Topic { final String id, name; Topic({required this.id, required this.name}); factory Topic.fromJson(Map<String,dynamic> j)=>Topic(id:j['id'], name:j['name']); }
class Textbook { final String id,title,author,license,webUrl; final String? coverUrl; final List<String> topicIds; Textbook({required this.id,required this.title,required this.author,required this.license,required this.webUrl,this.coverUrl,required this.topicIds}); factory Textbook.fromJson(Map<String,dynamic> j)=>Textbook(id:j['id'],title:j['title'],author:j['author'],license:j['license'],webUrl:j['webUrl'],coverUrl:j['coverUrl'],topicIds:(j['topicIds'] as List).cast<String>()); }
class Audiobook { final String id,title,author,source; final String audioUrl; final String? imageUrl; final List<String> topicIds; final int? durationSec; Audiobook({required this.id,required this.title,required this.author,required this.source,required this.audioUrl,this.imageUrl,required this.topicIds,this.durationSec}); factory Audiobook.fromJson(Map<String,dynamic> j)=>Audiobook(id:j['id'],title:j['title'],author:j['author'],source:j['source'],audioUrl:j['audioUrl'],imageUrl:j['imageUrl'],topicIds:(j['topicIds'] as List).cast<String>(),durationSec:j['durationSec']); }
class Person { final String id,name,lifespan,headline; final List<String> keyWorks; Person({required this.id,required this.name,required this.lifespan,required this.headline,required this.keyWorks}); factory Person.fromJson(Map<String,dynamic> j)=>Person(id:j['id'],name:j['name'],lifespan:j['lifespan'],headline:j['headline'],keyWorks:(j['keyWorks'] as List).cast<String>()); }
class Course { final String id,title,level; final List<String> topicIds; final List<String> sources; Course({required this.id,required this.title,required this.level,required this.topicIds,required this.sources}); factory Course.fromJson(Map<String,dynamic> j)=>Course(id:j['id'],title:j['title'],level:j['level']??'Undergraduate',topicIds:(j['topicIds'] as List).cast<String>(),sources:(j['sources'] as List).cast<String>()); }

// ======= DATA REPOSITORY =======
class Catalog { final List<Topic> topics; final List<Textbook> textbooks; final List<Audiobook> audiobooks; final List<Person> people; final List<Course> courses; Catalog({required this.topics,required this.textbooks,required this.audiobooks,required this.people,required this.courses}); }

final catalogProvider = FutureProvider<Catalog>((ref) async {
  final topicsJson = jsonDecode(await rootBundle.loadString('assets/data/topics.json'));
  final textbooksJson = jsonDecode(await rootBundle.loadString('assets/data/textbooks.json'));
  final audiobooksJson = jsonDecode(await rootBundle.loadString('assets/data/audiobooks.json'));
  final peopleJson = jsonDecode(await rootBundle.loadString('assets/data/people.json'));
  final coursesJson = jsonDecode(await rootBundle.loadString('assets/data/courses.json'));
  return Catalog(
    topics: (topicsJson['topics'] as List).map((e)=>Topic.fromJson(e)).toList(),
    textbooks: (textbooksJson['textbooks'] as List).map((e)=>Textbook.fromJson(e)).toList(),
    audiobooks: (audiobooksJson['audiobooks'] as List).map((e)=>Audiobook.fromJson(e)).toList(),
    people: (peopleJson['people'] as List).map((e)=>Person.fromJson(e)).toList(),
    courses: (coursesJson['courses'] as List).map((e)=>Course.fromJson(e)).toList(),
  );
});

final searchQueryProvider = StateProvider<String>((_) => '');

// ======= ROUTER =======
GoRouter _router(WidgetRef ref) => GoRouter(
  routes: [
    GoRoute(path: '/', builder: (c,s)=> const RootShell()),
    GoRoute(path: '/audiobook', builder: (c,s){ final a = s.extra as Audiobook; return AudiobookPlayerPage(audiobook: a); }),
    GoRoute(path: '/textbook', builder: (c,s){ final t = s.extra as Textbook; return TextbookDetailPage(textbook: t); }),
    GoRoute(path: '/person', builder: (c,s){ final p = s.extra as Person; return PersonDetailPage(person: p); }),
    GoRoute(path: '/course', builder: (c,s){ final co = s.extra as Course; return CourseDetailPage(course: co); }),
  ],
);

// ======= APP =======
void main() { runApp(const ProviderScope(child: BetterPsychApp())); }

class BetterPsychApp extends ConsumerWidget { const BetterPsychApp({super.key}); @override Widget build(BuildContext context, WidgetRef ref) { return MaterialApp.router(title: 'BetterPsych', theme: ThemeData(useMaterial3:true, colorSchemeSeed: Colors.indigo), routerConfig: _router(ref)); }}

class RootShell extends ConsumerStatefulWidget { const RootShell({super.key}); @override ConsumerState<RootShell> createState()=>_RootShellState(); }
class _RootShellState extends ConsumerState<RootShell> {
  int _index = 0; final _tabs = const [CoursesTab(), AudiobooksTab(), TextbooksTab(), PeopleTab(), LibraryTab()];
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: const Text('BetterPsych'), actions:[IconButton(icon: const Icon(Icons.search), onPressed: ()=> showSearchSheet(context, ref))]),
      body: _tabs[_index],
      bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (i)=>setState(()=>_index=i), destinations: const [
        NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label:'Courses'),
        NavigationDestination(icon: Icon(Icons.headphones_outlined), selectedIcon: Icon(Icons.headphones), label:'Audio'),
        NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label:'Textbooks'),
        NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label:'People'),
        NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label:'Library'),
      ]),
    );
  }
}

// ======= TABS =======
class CoursesTab extends ConsumerWidget { const CoursesTab({super.key}); @override Widget build(BuildContext context, WidgetRef ref){ final catalog = ref.watch(catalogProvider); return catalog.when(data: (c){ return ListView.builder(itemCount: c.courses.length, itemBuilder: (context,i){ final course = c.courses[i]; return Card(margin: const EdgeInsets.all(8), child: ListTile(title: Text(course.title), subtitle: Text('Level: ${course.level}'), trailing: const Icon(Icons.chevron_right), onTap: ()=> context.push('/course', extra: course))); }); }, loading: ()=> const Center(child: CircularProgressIndicator()), error: (e,_)=> Center(child: Text('Error: $e'))); }}
class AudiobooksTab extends ConsumerWidget { const AudiobooksTab({super.key}); @override Widget build(BuildContext context, WidgetRef ref){ final catalog = ref.watch(catalogProvider); return catalog.when(data: (c){ return ListView.builder(itemCount: c.audiobooks.length, itemBuilder: (context,i){ final a = c.audiobooks[i]; return ListTile(leading: a.imageUrl==null? const Icon(Icons.headphones): CachedNetworkImage(imageUrl: a.imageUrl!, width: 48, height: 48, fit: BoxFit.cover), title: Text(a.title), subtitle: Text('${a.author} · ${a.source}'), trailing: const Icon(Icons.play_arrow), onTap: ()=> context.push('/audiobook', extra: a)); }); }, loading: ()=> const Center(child: CircularProgressIndicator()), error: (e,_)=> Center(child: Text('Error: $e'))); }}
class TextbooksTab extends ConsumerWidget { const TextbooksTab({super.key}); @override Widget build(BuildContext context, WidgetRef ref){ final catalog = ref.watch(catalogProvider); return catalog.when(data: (c){ return ListView.builder(itemCount: c.textbooks.length, itemBuilder: (context,i){ final t = c.textbooks[i]; return Card(margin: const EdgeInsets.all(8), child: ListTile(leading: t.coverUrl==null? const Icon(Icons.menu_book): CachedNetworkImage(imageUrl: t.coverUrl!, width: 48, height: 48, fit: BoxFit.cover), title: Text(t.title), subtitle: Text('${t.author} · ${t.license}'), trailing: const Icon(Icons.chevron_right), onTap: ()=> context.push('/textbook', extra: t))); }); }, loading: ()=> const Center(child: CircularProgressIndicator()), error: (e,_)=> Center(child: Text('Error: $e'))); }}
class PeopleTab extends ConsumerWidget { const PeopleTab({super.key}); @override Widget build(BuildContext context, WidgetRef ref){ final catalog = ref.watch(catalogProvider); return catalog.when(data: (c){ return ListView.builder(itemCount: c.people.length, itemBuilder: (context,i){ final p = c.people[i]; return ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(p.name), subtitle: Text('${p.lifespan} — ${p.headline}'), onTap: ()=> context.push('/person', extra: p)); }); }, loading: ()=> const Center(child: CircularProgressIndicator()), error: (e,_)=> Center(child: Text('Error: $e'))); }}
class LibraryTab extends StatelessWidget { const LibraryTab({super.key}); @override Widget build(BuildContext context){ return const Center(child: Text('Your saved items will appear here (coming soon).')); }}

// ======= DETAIL PAGES =======
class TextbookDetailPage extends StatelessWidget { final Textbook textbook; const TextbookDetailPage({super.key, required this.textbook}); @override Widget build(BuildContext context){ return Scaffold(appBar: AppBar(title: Text(textbook.title)), body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text(textbook.title, style: const TextStyle(fontSize:20,fontWeight:FontWeight.bold)), Text('by ${textbook.author}'), Text('License: ${textbook.license}'), const SizedBox(height:16), ElevatedButton(onPressed: () async { final uri = Uri.parse(textbook.webUrl); if(await canLaunchUrl(uri)) await launchUrl(uri); }, child: const Text('Open Source'))]))); }}
class PersonDetailPage extends StatelessWidget { final Person person; const PersonDetailPage({super.key, required this.person}); @override Widget build(BuildContext context){ return Scaffold(appBar: AppBar(title: Text(person.name)), body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text('${person.name} (${person.lifespan})', style: const TextStyle(fontSize:20,fontWeight:FontWeight.bold)), const SizedBox(height:8), Text(person.headline), const SizedBox(height:8), const Text('Key Works:', style: TextStyle(fontWeight: FontWeight.w600)), ...person.keyWorks.map((w)=> Text(w))]))); }}
class CourseDetailPage extends ConsumerWidget { final Course course; const CourseDetailPage({super.key, required this.course}); @override Widget build(BuildContext context, WidgetRef ref){ final cat = ref.watch(catalogProvider).valueOrNull; return Scaffold(appBar: AppBar(title: Text(course.title)), body: Padding(padding: const EdgeInsets.all(16), child: cat==null? const Center(child: CircularProgressIndicator()): Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Text('${course.level} course', style: const TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height:8), Wrap(spacing:8, children: course.topicIds.map((id){ final name = cat.topics.firstWhere((t)=>t.id==id).name; return Chip(label: Text(name)); }).toList()), const SizedBox(height:16), const Text('Suggested Resources:', style: TextStyle(fontWeight: FontWeight.w600)), ...course.sources.map((sid){ final tb = cat.textbooks.where((t)=>t.id==sid); if(tb.isNotEmpty) return ListTile(title: Text(tb.first.title)); final ab = cat.audiobooks.where((a)=>a.id==sid); if(ab.isNotEmpty) return ListTile(title: Text(ab.first.title)); return ListTile(title: Text('Unknown resource: $sid')); })]))); }}

// ======= AUDIOBOOK PLAYER =======
class AudiobookPlayerPage extends StatefulWidget { final Audiobook audiobook; const AudiobookPlayerPage({super.key, required this.audiobook}); @override State<AudiobookPlayerPage> createState()=>_AudiobookPlayerPageState(); }
class _AudiobookPlayerPageState extends State<AudiobookPlayerPage>{ final _player = AudioPlayer(); bool _ready=false; @override void initState(){ super.initState(); _init(); } Future<void> _init() async { final session=await AudioSession.instance; await session.configure(const AudioSessionConfiguration.music()); try{ await _player.setUrl(widget.audiobook.audioUrl); setState(()=>_ready=true);} catch(e){ debugPrint('Audio error: $e'); } } @override void dispose(){ _player.dispose(); super.dispose(); } @override Widget build(BuildContext context){ return Scaffold(appBar: AppBar(title: Text(widget.audiobook.title)), body: Column(children:[ListTile(title: Text(widget.audiobook.title), subtitle: Text(widget.audiobook.author)), if(!_ready) const LinearProgressIndicator(), Row(mainAxisAlignment: MainAxisAlignment.center, children:[ IconButton(icon: const Icon(Icons.replay_10), onPressed: ()=> _player.seek(_player.position - const Duration(seconds:10))), StreamBuilder<PlayerState>(stream: _player.playerStateStream, builder: (_,snap){ final playing=snap.data?.playing??false; return IconButton(icon: Icon(playing? Icons.pause: Icons.play_arrow), iconSize:56, onPressed: () async { if(playing){ await _player.pause(); } else { await _player.play(); } }); }), IconButton(icon: const Icon(Icons.forward_10), onPressed: ()=> _player.seek(_player.position + const Duration(seconds:10)))]), ])); }}
