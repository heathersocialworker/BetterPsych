import SwiftUI

struct QuizView: View {
    let items: [QuizItem]
    @State private var current = 0
    @State private var selected: Int? = nil
    @State private var score = 0
    @State private var finished = false
    @State private var showExplanation = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if finished {
                VStack(spacing: 12) {
                    Text("Quiz Complete").font(.title2)
                    Text("Score: \(score) / \(items.count)").font(.headline)
                    Button("Retake") { reset() }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if items.isEmpty {
                Text("No questions")
            } else {
                let q = items[current]
                Text("Question \(current + 1) of \(items.count)")
                    .font(.footnote).foregroundStyle(.secondary)
                Text(q.question).font(.title3)
                
                VStack(spacing: 8) {
                    ForEach(0..<q.choices.count, id: \.self) { idx in
                        Button {
                            selected = idx
                            showExplanation = true
                            if idx == q.answerIndex { score += 1 }
                        } label: {
                            HStack {
                                Text(q.choices[idx])
                                Spacer()
                                if showExplanation && idx == q.answerIndex {
                                    Image(systemName: "checkmark.circle")
                                }
                            }
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(colorFor(idx: idx, correctIndex: q.answerIndex))
                        .disabled(showExplanation)
                    }
                }
                
                if showExplanation {
                    Text(q.explanation)
                        .font(.callout)
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                
                HStack {
                    Button("Back") {
                        current = max(0, current - 1)
                        selected = nil
                        showExplanation = false
                    }.disabled(current == 0)
                    
                    Spacer()
                    
                    Button(current == items.count - 1 ? "Finish" : "Next") {
                        if current == items.count - 1 {
                            finished = true
                        } else {
                            current += 1
                            selected = nil
                            showExplanation = false
                        }
                    }.disabled(!showExplanation)
                }
            }
        }
        .padding()
        .navigationTitle("Quiz")
    }
    
    private func colorFor(idx: Int, correctIndex: Int) -> Color {
        guard let selected = selected, selected == idx else { return .accentColor }
        return idx == correctIndex ? .green : .red
    }
    
    private func reset() {
        current = 0
        selected = nil
        score = 0
        finished = false
        showExplanation = false
    }
}