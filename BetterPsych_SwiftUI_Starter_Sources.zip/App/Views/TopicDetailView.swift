import SwiftUI

extension Topic: Hashable {
    public static func == (lhs: Topic, rhs: Topic) -> Bool { lhs.id == rhs.id }
    public func hash(into hasher: inout Hasher) { hasher.combine(id) }
}

struct TopicDetailView: View {
    let topic: Topic
    
    var body: some View {
        List {
            Section("Summary") {
                Text(topic.summary)
            }
            Section("Flashcards") {
                NavigationLink("Study Flashcards") { FlashcardsView(cards: topic.flashcards) }
            }
            Section("Quiz") {
                NavigationLink("Take Quiz") { QuizView(items: topic.quiz) }
            }
            if !topic.audioList.isEmpty {
                Section("Audio") {
                    ForEach(topic.audioList, id: \.self) { id in
                        Text(id)
                    }
                }
            }
            if !topic.readingList.isEmpty {
                Section("Readings") {
                    ForEach(topic.readingList, id: \.self) { id in
                        Text(id)
                    }
                }
            }
        }
        .navigationTitle(topic.title)
    }
}