import SwiftUI

struct FlashcardsView: View {
    let cards: [Flashcard]
    @State private var index: Int = 0
    @State private var showAnswer = false
    
    var body: some View {
        VStack(spacing: 16) {
            if cards.isEmpty {
                Text("No flashcards")
            } else {
                let card = cards[index]
                Text(card.q)
                    .font(.title2)
                    .multilineTextAlignment(.center)
                    .padding()
                
                if showAnswer {
                    Text(card.a)
                        .font(.body)
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .transition(.opacity)
                }
                
                HStack {
                    Button("Prev") {
                        withAnimation {
                            index = max(0, index - 1)
                            showAnswer = false
                        }
                    }.disabled(index == 0)
                    
                    Spacer()
                    
                    Button(showAnswer ? "Hide Answer" : "Show Answer") {
                        withAnimation { showAnswer.toggle() }
                    }
                    
                    Spacer()
                    
                    Button("Next") {
                        withAnimation {
                            index = min(cards.count - 1, index + 1)
                            showAnswer = false
                        }
                    }.disabled(index == cards.count - 1)
                }
                .padding(.horizontal)
                
                Text("Card \(index + 1) of \(cards.count)")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .padding()
        .navigationTitle("Flashcards")
    }
}