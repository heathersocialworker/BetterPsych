import SwiftUI

@main
struct BetterPsychApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}