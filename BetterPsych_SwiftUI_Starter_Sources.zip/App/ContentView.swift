import SwiftUI

struct ContentView: View {
    @State private var topics: [Topic] = []
    
    var body: some View {
        NavigationStack {
            List(topics) { topic in
                NavigationLink(value: topic) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(topic.title)
                            .font(.headline)
                        Text(topic.summary)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("BetterPsych")
            .navigationDestination(for: Topic.self) { topic in
                TopicDetailView(topic: topic)
            }
            .task {
                topics = BetterPsychData.loadTopics()
            }
        }
    }
}