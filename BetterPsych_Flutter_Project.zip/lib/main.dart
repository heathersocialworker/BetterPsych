import 'package:flutter/material.dart';

void main() {
  runApp(const BetterPsychApp());
}

class BetterPsychApp extends StatelessWidget {
  const BetterPsychApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BetterPsych',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const Scaffold(
        body: Center(child: Text('BetterPsych App Scaffold')),
      ),
    );
  }
}
