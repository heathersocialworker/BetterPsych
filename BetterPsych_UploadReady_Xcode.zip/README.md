# BetterPsych (Upload-Ready iOS Project)

This is a minimal SwiftUI Xcode project you can upload to GitHub, open, and build immediately.

## How to use
1. Upload all files/folders in this zip to your GitHub repo root.
2. Open `BetterPsych.xcodeproj` in Xcode.
3. Target: **BetterPsych** → **Signing & Capabilities** → set a unique **Bundle Identifier** and select your **Team**.
4. Product → **Clean Build Folder** → **Run** on iPhone simulator.
