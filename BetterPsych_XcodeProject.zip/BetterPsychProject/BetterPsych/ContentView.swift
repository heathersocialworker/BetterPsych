
import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("BetterPsych")
                .font(.largeTitle)
                .padding()
            Text("Welcome to your recovery companion app!")
        }
    }
}

#Preview {
    ContentView()
}
